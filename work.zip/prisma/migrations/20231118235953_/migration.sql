-- AlterTable
ALTER TABLE "WalletAssignment" ALTER COLUMN "detachedAt" DROP NOT NULL;
