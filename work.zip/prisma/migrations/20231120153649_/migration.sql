-- AlterTable
ALTER TABLE "Wallet" ALTER COLUMN "lastAssignedAt" DROP NOT NULL;
