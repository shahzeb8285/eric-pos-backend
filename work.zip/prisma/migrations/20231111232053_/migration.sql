/*
  Warnings:

  - You are about to drop the column `txnDirection` on the `Transactions` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Transactions" DROP COLUMN "txnDirection";

-- DropEnum
DROP TYPE "TxnDirection";
