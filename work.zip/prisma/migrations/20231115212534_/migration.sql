-- AlterTable
ALTER TABLE "Wallet" ADD COLUMN     "isReadyForSettlement" BOOLEAN NOT NULL DEFAULT false;
