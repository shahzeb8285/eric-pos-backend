import { Injectable } from '@nestjs/common';
import { CreateBalanceDto } from './dto/create-balance.dto';
import { PrismaService } from 'nestjs-prisma';

@Injectable()
export class BalancesService {
  constructor(private prisma: PrismaService,
  ) {

    // prisma.$on('query', async (e) => {
    //   // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    //   // @ts-ignore
    //   console.log(`${e.query} ${e.params}`);
    // });
   }

  create(createBalanceDto: CreateBalanceDto) {
    return this.prisma.balances.create({
      data: createBalanceDto,
      include: {
        wallet: {
          select: {
            user: {
              select: {
                merchant: {
                  select: {
                    configs:true
                  }
                }
              }
            }
          }
        }
      }
    });
  }

async  findOne(wallet: string, symbol: string) {
   
    const item = await  this.prisma.balances.findUnique({
      where: {
        walletAddress: wallet,
        currencySymbol: symbol
      },
      include: {
        wallet: {
          select: {
            user: {
              select: {
                merchant: {
                  select: {
                    configs:true
                  }
                }
              }
            }
          }
        }
      }
    })
  
    return item
  }

  // where: {
  //   AND: [
  //     {
  //       walletAddress: wallet
  //     },
  //     {
  //       currencySymbol: symbol
  //     }
  //   ]
  // }


  updateBalance(id: string, updatedBalance: string) {
    return this.prisma.balances.update({
      where: {
        id
      },
      data: {
        balance: updatedBalance
      },
      include: {
        wallet: {
          select: {
            user: {
              select: {
                merchant: {
                  select: {
                    configs:true
                  }
                }
              }
            }
          }
        }
      }
    })
  }
}
