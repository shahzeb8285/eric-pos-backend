export class CreateBalanceDto {
    walletAddress: string
    currencySymbol: string
    balance: string
}
