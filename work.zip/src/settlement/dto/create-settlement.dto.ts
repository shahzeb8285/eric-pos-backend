export class CreateSettlementDto {
    settlementTxnHash: string
    settlementAddress: string
    settlementAmount: string
    currencySymbol: string
    commissionAmount: string
    commissionTxnHash: string
    commissionAddress: string
    totalGasFeePaid: string
    fromWalletAddress: string
}

