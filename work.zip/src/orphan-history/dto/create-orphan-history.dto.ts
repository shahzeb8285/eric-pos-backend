export class CreateOrphanHistoryDto {
    txnHash: string
    userId: string
}


