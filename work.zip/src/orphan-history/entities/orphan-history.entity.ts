export class OrphanHistory {}
