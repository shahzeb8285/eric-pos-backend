
export class CreateWalletDto {
    userId?: string
}