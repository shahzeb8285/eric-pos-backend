export class Wallet { }
