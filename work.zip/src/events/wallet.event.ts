export class WalletCreatedEvent {
    walletAddress: string;
}

export class WalletBalanceExceedsEvent {
    walletAddress: string;
}