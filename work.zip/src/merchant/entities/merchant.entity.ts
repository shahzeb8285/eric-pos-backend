export class Merchant {}
