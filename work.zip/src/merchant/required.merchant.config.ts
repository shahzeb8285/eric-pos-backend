export default ["maxIDRT", "minIDRT", "minBnb", "maxBnb",
    "merchantCallBackUrl", "bnbWallet", "commissionWallet",
    "merchantWallet", "minCommission", "commissionPercentage"]
